package CoronaProvider.licensing.google;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Log;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.ansca.corona.purchasing.StoreServices;
import com.ansca.corona.storage.FileServices;
import com.google.android.vending.licensing.AESObfuscator;
import com.google.android.vending.licensing.APKExpansionPolicy;
import com.google.android.vending.licensing.LicenseChecker;
import com.google.android.vending.licensing.LicenseCheckerCallback;
import com.google.android.vending.licensing.Obfuscator;
import com.google.android.vending.licensing.Policy;
import com.google.android.vending.licensing.StrictPolicy;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;
import java.util.Random;

public class LuaLoader implements JavaFunction {
  private static final String LAST_VERSION_CHECKED = "LAST_VERSION_CHECKED";
  
  public static final String PREFS_FILE = "CoronaProvider.licensing.google.lualoader";
  
  private static byte[] SALT;
  
  private static final String SALT_STRING = "salt";
  
  private CoronaRuntimeTaskDispatcher fDispatcher;
  
  private int fListener;
  
  private Policy licenseCheckPolicy;
  
  private String licenseKey;
  
  private LicenseChecker mChecker;
  
  private LicenseCheckerCallback mLicenseCheckerCallback;
  
  public LuaLoader() {
    initialize();
  }
  
  private void callLuaCallback(final boolean isVerified, final String response, final boolean isError, final String errorType) {
    this.fDispatcher.send(new CoronaRuntimeTask() {
          public void executeUsing(CoronaRuntime param1CoronaRuntime) {
            try {
              LuaState luaState = param1CoronaRuntime.getLuaState();
              CoronaLua.newEvent(luaState, "licensing");
              luaState.pushBoolean(isVerified);
              luaState.setField(-2, "isVerified");
              boolean bool = isError;
              if (bool) {
                luaState.pushBoolean(bool);
              } else {
                luaState.pushNil();
              } 
              luaState.setField(-2, "isError");
              if (isError) {
                luaState.pushString(errorType);
              } else {
                luaState.pushNil();
              } 
              luaState.setField(-2, "errorType");
              luaState.pushString(response);
              luaState.setField(-2, "response");
              luaState.pushString("google");
              luaState.setField(-2, "provider");
              luaState.pushNumber(LuaLoader.this.licenseCheckPolicy.getValidityTimestamp());
              luaState.setField(-2, "expiration");
              luaState.newTable(LuaLoader.this.licenseCheckPolicy.getExpansionURLCount(), 0);
              int i = 0;
              while (i < LuaLoader.this.licenseCheckPolicy.getExpansionURLCount()) {
                luaState.newTable(0, 3);
                luaState.pushString(LuaLoader.this.licenseCheckPolicy.getExpansionURL(i));
                luaState.setField(-2, "url");
                luaState.pushString(LuaLoader.this.licenseCheckPolicy.getExpansionFileName(i));
                luaState.setField(-2, "fileName");
                luaState.pushNumber(LuaLoader.this.licenseCheckPolicy.getExpansionFileSize(i));
                luaState.setField(-2, "fileSize");
                luaState.setField(-2, Integer.toString(++i));
              } 
              luaState.setField(-2, "expansionFiles");
              CoronaLua.dispatchEvent(luaState, LuaLoader.this.fListener, 0);
              return;
            } catch (Exception exception) {
              exception.printStackTrace();
              return;
            } 
          }
        });
  }
  
  private boolean initLicenseChecker(String paramString1, String paramString2) {
    this.mLicenseCheckerCallback = new MyLicenseCheckerCallback();
    String str1 = Settings.Secure.getString(CoronaEnvironment.getApplicationContext().getContentResolver(), "android_id");
    String str2 = CoronaEnvironment.getApplicationContext().getPackageName();
    AESObfuscator aESObfuscator = new AESObfuscator(SALT, str2, str1);
    if (paramString2.equals("strict")) {
      this.licenseCheckPolicy = (Policy)new StrictPolicy();
    } else {
      this.licenseCheckPolicy = (Policy)new APKExpansionPolicy(CoronaEnvironment.getApplicationContext(), (Obfuscator)aESObfuscator);
    } 
    try {
      this.mChecker = new LicenseChecker(CoronaEnvironment.getApplicationContext(), this.licenseCheckPolicy, paramString1);
      return true;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.e("Corona", "Invalid public key", illegalArgumentException);
      return false;
    } 
  }
  
  public static boolean isNewAppVersion() {
    byte b;
    Context context = CoronaEnvironment.getApplicationContext();
    boolean bool = false;
    int i = context.getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0).getInt("LAST_VERSION_CHECKED", 0);
    try {
      b = (context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).versionCode;
    } catch (Exception exception) {
      b = 0;
    } 
    if (b > i)
      bool = true; 
    return bool;
  }
  
  private void setExpansionFileNames() {
    Context context = CoronaEnvironment.getApplicationContext();
    if (context != null) {
      FileServices fileServices = new FileServices(context);
      for (int i = 0; i < this.licenseCheckPolicy.getExpansionFileNameCount(); i++) {
        String str = this.licenseCheckPolicy.getExpansionFileName(i);
        if (str != null)
          if (str.startsWith("main")) {
            fileServices.setMainExpansionFileName(str);
          } else if (str.startsWith("patch")) {
            fileServices.setPatchExpansionFileName(str);
          }  
      } 
      fileServices.loadExpansionFiles();
    } 
  }
  
  public static void setLastCheckedAppVersion() {
    Context context = CoronaEnvironment.getApplicationContext();
    int i = 0;
    SharedPreferences.Editor editor = context.getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0).edit();
    try {
      int j = (context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).versionCode;
      i = j;
    } catch (Exception exception) {}
    editor.putInt("LAST_VERSION_CHECKED", i);
    editor.commit();
  }
  
  public int init(LuaState paramLuaState) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getTop : ()I
    //   4: istore_2
    //   5: aload_1
    //   6: ldc 'require'
    //   8: invokevirtual getGlobal : (Ljava/lang/String;)V
    //   11: aload_1
    //   12: ldc_w 'config'
    //   15: invokevirtual pushString : (Ljava/lang/String;)V
    //   18: aload_1
    //   19: iconst_1
    //   20: iconst_m1
    //   21: invokevirtual call : (II)V
    //   24: aload_1
    //   25: ldc_w 'application'
    //   28: invokevirtual getGlobal : (Ljava/lang/String;)V
    //   31: aload_1
    //   32: iconst_m1
    //   33: invokevirtual isTable : (I)Z
    //   36: ifeq -> 137
    //   39: aload_1
    //   40: iconst_m1
    //   41: ldc_w 'license'
    //   44: invokevirtual getField : (ILjava/lang/String;)V
    //   47: aload_1
    //   48: iconst_m1
    //   49: invokevirtual isTable : (I)Z
    //   52: ifeq -> 137
    //   55: aload_1
    //   56: iconst_m1
    //   57: ldc_w 'google'
    //   60: invokevirtual getField : (ILjava/lang/String;)V
    //   63: aload_1
    //   64: iconst_m1
    //   65: invokevirtual isTable : (I)Z
    //   68: ifeq -> 137
    //   71: aload_1
    //   72: iconst_m1
    //   73: ldc_w 'key'
    //   76: invokevirtual getField : (ILjava/lang/String;)V
    //   79: aload_1
    //   80: iconst_m1
    //   81: invokevirtual isString : (I)Z
    //   84: ifeq -> 97
    //   87: aload_1
    //   88: iconst_m1
    //   89: invokevirtual toString : (I)Ljava/lang/String;
    //   92: astore #5
    //   94: goto -> 102
    //   97: ldc_w ''
    //   100: astore #5
    //   102: aload_1
    //   103: bipush #-2
    //   105: ldc_w 'policy'
    //   108: invokevirtual getField : (ILjava/lang/String;)V
    //   111: aload_1
    //   112: iconst_m1
    //   113: invokevirtual isString : (I)Z
    //   116: ifeq -> 129
    //   119: aload_1
    //   120: iconst_m1
    //   121: invokevirtual toString : (I)Ljava/lang/String;
    //   124: astore #6
    //   126: goto -> 146
    //   129: ldc_w ''
    //   132: astore #6
    //   134: goto -> 146
    //   137: ldc_w ''
    //   140: astore #6
    //   142: aload #6
    //   144: astore #5
    //   146: aload #5
    //   148: ldc_w ''
    //   151: invokevirtual equals : (Ljava/lang/Object;)Z
    //   154: ifne -> 186
    //   157: invokestatic getTargetedAppStoreName : ()Ljava/lang/String;
    //   160: ldc_w 'google'
    //   163: invokevirtual equals : (Ljava/lang/Object;)Z
    //   166: ifne -> 181
    //   169: invokestatic getTargetedAppStoreName : ()Ljava/lang/String;
    //   172: ldc_w 'none'
    //   175: invokevirtual equals : (Ljava/lang/Object;)Z
    //   178: ifeq -> 186
    //   181: iconst_1
    //   182: istore_3
    //   183: goto -> 188
    //   186: iconst_0
    //   187: istore_3
    //   188: iload_3
    //   189: istore #4
    //   191: iload_3
    //   192: ifeq -> 205
    //   195: aload_0
    //   196: aload #5
    //   198: aload #6
    //   200: invokespecial initLicenseChecker : (Ljava/lang/String;Ljava/lang/String;)Z
    //   203: istore #4
    //   205: aload_1
    //   206: iload_2
    //   207: invokevirtual setTop : (I)V
    //   210: aload_1
    //   211: iload #4
    //   213: invokevirtual pushBoolean : (Z)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  protected void initialize() {
    SharedPreferences sharedPreferences = CoronaEnvironment.getApplicationContext().getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0);
    String str2 = sharedPreferences.getString("salt", null);
    String str1 = str2;
    if (str2 == null) {
      SALT = new byte[20];
      (new Random()).nextBytes(SALT);
      str1 = new String(SALT);
      SharedPreferences.Editor editor = sharedPreferences.edit();
      editor.putString("salt", str1);
      editor.commit();
    } 
    SALT = str1.getBytes();
  }
  
  public int invoke(LuaState paramLuaState) {
    initialize();
    this.fDispatcher = new CoronaRuntimeTaskDispatcher(paramLuaState);
    InitWrapper initWrapper = new InitWrapper();
    VerifyWrapper verifyWrapper = new VerifyWrapper();
    IsGoogleExpansionFileRequiredWrapper isGoogleExpansionFileRequiredWrapper = new IsGoogleExpansionFileRequiredWrapper();
    GetExternalStorageStateWrapper getExternalStorageStateWrapper = new GetExternalStorageStateWrapper();
    GetAvailableExternalSpaceWrapper getAvailableExternalSpaceWrapper = new GetAvailableExternalSpaceWrapper();
    IsNewAppVersionWrapper isNewAppVersionWrapper = new IsNewAppVersionWrapper();
    GetFileNamesFromPreferencesWrapper getFileNamesFromPreferencesWrapper = new GetFileNamesFromPreferencesWrapper();
    LoadExpansionFilesWrapper loadExpansionFilesWrapper = new LoadExpansionFilesWrapper();
    paramLuaState.register(paramLuaState.toString(1), new NamedJavaFunction[] { initWrapper, verifyWrapper, isGoogleExpansionFileRequiredWrapper, getExternalStorageStateWrapper, getAvailableExternalSpaceWrapper, isNewAppVersionWrapper, getFileNamesFromPreferencesWrapper, loadExpansionFilesWrapper });
    return 1;
  }
  
  public int verify(LuaState paramLuaState) {
    Context context = CoronaEnvironment.getApplicationContext();
    if (context != null)
      context.enforceCallingOrSelfPermission("com.android.vending.CHECK_LICENSE", null); 
    boolean bool3 = CoronaLua.isListener(paramLuaState, 1, "licensing");
    boolean bool1 = false;
    boolean bool2 = false;
    if ((bool3 && this.mChecker != null && StoreServices.getTargetedAppStoreName().equals("google")) || StoreServices.getTargetedAppStoreName().equals("none")) {
      this.fListener = CoronaLua.newRef(paramLuaState, 1);
      bool1 = bool2;
      if (paramLuaState.isBoolean(2))
        bool1 = paramLuaState.toBoolean(2); 
      this.mChecker.checkAccess(this.mLicenseCheckerCallback, bool1);
      bool1 = true;
    } 
    paramLuaState.pushBoolean(bool1);
    return 1;
  }
  
  public class GetAvailableExternalSpaceWrapper implements NamedJavaFunction {
    public String getName() {
      return "getAvailableExternalSpace";
    }
    
    public int invoke(LuaState param1LuaState) {
      double d;
      try {
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
        d = statFs.getBlockSize();
        int i = statFs.getAvailableBlocks();
        double d1 = i;
        Double.isNaN(d);
        Double.isNaN(d1);
        d *= d1;
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not retrieve the available free space for: ");
        stringBuilder.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        Log.w("Corona", stringBuilder.toString());
        d = Double.MAX_VALUE;
      } 
      param1LuaState.pushNumber(d);
      return 1;
    }
  }
  
  private class GetExternalStorageStateWrapper implements NamedJavaFunction {
    private GetExternalStorageStateWrapper() {}
    
    public String getName() {
      return "getExternalStorageState";
    }
    
    public int invoke(LuaState param1LuaState) {
      param1LuaState.pushString(Environment.getExternalStorageState());
      return 1;
    }
  }
  
  public class GetFileNamesFromPreferencesWrapper implements NamedJavaFunction {
    public String getName() {
      return "getFileNamesFromPreferences";
    }
    
    public int invoke(LuaState param1LuaState) {
      int j = LuaLoader.this.licenseCheckPolicy.getExpansionFileNameCount();
      int i = 0;
      param1LuaState.newTable(j, 0);
      j = param1LuaState.getTop();
      while (i < LuaLoader.this.licenseCheckPolicy.getExpansionFileNameCount()) {
        param1LuaState.pushString(LuaLoader.this.licenseCheckPolicy.getExpansionFileName(i));
        param1LuaState.rawSet(j, ++i);
      } 
      return 1;
    }
  }
  
  private class InitWrapper implements NamedJavaFunction {
    private InitWrapper() {}
    
    public String getName() {
      return "init";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.init(param1LuaState);
    }
  }
  
  private class IsGoogleExpansionFileRequiredWrapper implements NamedJavaFunction {
    private IsGoogleExpansionFileRequiredWrapper() {}
    
    public String getName() {
      return "isGoogleExpansionFileRequired";
    }
    
    public int invoke(LuaState param1LuaState) {
      // Byte code:
      //   0: iconst_0
      //   1: istore_3
      //   2: invokestatic getTargetedAppStoreName : ()Ljava/lang/String;
      //   5: astore #4
      //   7: ldc 'google'
      //   9: aload #4
      //   11: invokevirtual equals : (Ljava/lang/Object;)Z
      //   14: ifne -> 29
      //   17: iload_3
      //   18: istore_2
      //   19: ldc 'none'
      //   21: aload #4
      //   23: invokevirtual equals : (Ljava/lang/Object;)Z
      //   26: ifeq -> 98
      //   29: invokestatic getApplicationContext : ()Landroid/content/Context;
      //   32: astore #4
      //   34: aload #4
      //   36: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   39: aload #4
      //   41: invokevirtual getPackageName : ()Ljava/lang/String;
      //   44: sipush #128
      //   47: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
      //   50: astore #4
      //   52: iload_3
      //   53: istore_2
      //   54: aload #4
      //   56: ifnull -> 98
      //   59: iload_3
      //   60: istore_2
      //   61: aload #4
      //   63: getfield metaData : Landroid/os/Bundle;
      //   66: ifnull -> 98
      //   69: aload #4
      //   71: getfield metaData : Landroid/os/Bundle;
      //   74: ldc 'usesExpansionFile'
      //   76: iconst_0
      //   77: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
      //   80: istore_2
      //   81: goto -> 98
      //   84: astore #4
      //   86: ldc 'Corona'
      //   88: ldc 'isGoogleExpansionFileRequired'
      //   90: aload #4
      //   92: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   95: pop
      //   96: iload_3
      //   97: istore_2
      //   98: aload_1
      //   99: iload_2
      //   100: invokevirtual pushBoolean : (Z)V
      //   103: iconst_1
      //   104: ireturn
      // Exception table:
      //   from	to	target	type
      //   2	17	84	java/lang/Exception
      //   19	29	84	java/lang/Exception
      //   29	52	84	java/lang/Exception
      //   61	81	84	java/lang/Exception
    }
  }
  
  public class IsNewAppVersionWrapper implements NamedJavaFunction {
    public String getName() {
      return "isNewAppVersion";
    }
    
    public int invoke(LuaState param1LuaState) {
      param1LuaState.pushBoolean(LuaLoader.isNewAppVersion());
      return 1;
    }
  }
  
  public class LoadExpansionFilesWrapper implements NamedJavaFunction {
    public String getName() {
      return "loadExpansionFiles";
    }
    
    public int invoke(LuaState param1LuaState) {
      LuaLoader.this.setExpansionFileNames();
      return 0;
    }
  }
  
  private class MyLicenseCheckerCallback implements LicenseCheckerCallback {
    private MyLicenseCheckerCallback() {}
    
    private String translateResponse(int param1Int) {
      return (param1Int != 1) ? ((param1Int != 2) ? ((param1Int != 3) ? ((param1Int != 5) ? ((param1Int != 6) ? ((param1Int != 256) ? ((param1Int != 291) ? ((param1Int != 561) ? "" : "Not licensed") : "Unable to establish connection to Google's Licensing servers.\n\nThis may be the result of a poor internet connection, or no internet connection at all.\n\nPlease ensure that your device is connected to the internet and try again.") : "Licensed") : "Missing permission") : "Invalid public key") : "Not market managed") : "Non matching UID") : "Invalid package name";
    }
    
    public void allow(int param1Int) {
      LuaLoader.setLastCheckedAppVersion();
      LuaLoader.this.callLuaCallback(true, translateResponse(param1Int), false, "");
    }
    
    public void applicationError(int param1Int) {
      LuaLoader.this.callLuaCallback(false, translateResponse(param1Int), true, "configuration");
    }
    
    public void dontAllow(int param1Int) {
      boolean bool;
      String str;
      if (291 == param1Int) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        str = "network";
      } else {
        str = "";
      } 
      LuaLoader.this.callLuaCallback(false, translateResponse(param1Int), bool, str);
    }
  }
  
  private class VerifyWrapper implements NamedJavaFunction {
    private VerifyWrapper() {}
    
    public String getName() {
      return "verify";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.verify(param1LuaState);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\CoronaProvider\licensing\google\LuaLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */