package androidx.room.util;

public class SneakyThrow {
  public static void reThrow(Exception paramException) {
    sneakyThrow(paramException);
  }
  
  private static <E extends Throwable> void sneakyThrow(Throwable paramThrowable) throws E {
    throw (E)paramThrowable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\roo\\util\SneakyThrow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */