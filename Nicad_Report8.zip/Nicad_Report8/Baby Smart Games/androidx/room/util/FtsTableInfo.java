package androidx.room.util;

import android.database.Cursor;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FtsTableInfo {
  private static final String[] FTS_OPTIONS = new String[] { "tokenize=", "compress=", "content=", "languageid=", "matchinfo=", "notindexed=", "order=", "prefix=", "uncompress=" };
  
  public final Set<String> columns;
  
  public final String name;
  
  public final Set<String> options;
  
  public FtsTableInfo(String paramString1, Set<String> paramSet, String paramString2) {
    this.name = paramString1;
    this.columns = paramSet;
    this.options = parseOptions(paramString2);
  }
  
  public FtsTableInfo(String paramString, Set<String> paramSet1, Set<String> paramSet2) {
    this.name = paramString;
    this.columns = paramSet1;
    this.options = paramSet2;
  }
  
  static Set<String> parseOptions(String paramString) {
    Object object;
    if (paramString.isEmpty())
      return new HashSet<String>(); 
    paramString = paramString.substring(paramString.indexOf('(') + 1, paramString.lastIndexOf(')'));
    ArrayList<String> arrayList = new ArrayList();
    ArrayDeque<Character> arrayDeque = new ArrayDeque();
    byte b = -1;
    int i = 0;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != '"' && c != '\'')
        if (c != ',') {
          if (c != '[') {
            if (c != ']') {
              if (c != '`') {
                Object object1 = object;
                continue;
              } 
            } else {
              Object object1 = object;
              if (!arrayDeque.isEmpty()) {
                object1 = object;
                if (((Character)arrayDeque.peek()).charValue() == '[') {
                  arrayDeque.pop();
                  object1 = object;
                } 
              } 
              continue;
            } 
          } else {
            Object object1 = object;
            if (arrayDeque.isEmpty()) {
              arrayDeque.push(Character.valueOf(c));
              object1 = object;
            } 
            continue;
          } 
        } else {
          Object object1 = object;
          if (arrayDeque.isEmpty()) {
            arrayList.add(paramString.substring(object + 1, i).trim());
            int j = i;
          } 
          continue;
        }  
      if (arrayDeque.isEmpty()) {
        arrayDeque.push(Character.valueOf(c));
        Object object1 = object;
      } else {
        Object object1 = object;
        if (((Character)arrayDeque.peek()).charValue() == c) {
          arrayDeque.pop();
          object1 = object;
        } 
      } 
      continue;
      i++;
      object = SYNTHETIC_LOCAL_VARIABLE_4;
    } 
    arrayList.add(paramString.substring(object + 1).trim());
    HashSet<String> hashSet = new HashSet();
    for (String str : arrayList) {
      String[] arrayOfString = FTS_OPTIONS;
      int j = arrayOfString.length;
      for (i = 0; i < j; i++) {
        if (str.startsWith(arrayOfString[i]))
          hashSet.add(str); 
      } 
    } 
    return hashSet;
  }
  
  public static FtsTableInfo read(SupportSQLiteDatabase paramSupportSQLiteDatabase, String paramString) {
    return new FtsTableInfo(paramString, readColumns(paramSupportSQLiteDatabase, paramString), readOptions(paramSupportSQLiteDatabase, paramString));
  }
  
  private static Set<String> readColumns(SupportSQLiteDatabase paramSupportSQLiteDatabase, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PRAGMA table_info(`");
    stringBuilder.append(paramString);
    stringBuilder.append("`)");
    Cursor cursor = paramSupportSQLiteDatabase.query(stringBuilder.toString());
    null = new HashSet();
    try {
      if (cursor.getColumnCount() > 0) {
        int i = cursor.getColumnIndex("name");
        while (cursor.moveToNext())
          null.add(cursor.getString(i)); 
      } 
      return null;
    } finally {
      cursor.close();
    } 
  }
  
  private static Set<String> readOptions(SupportSQLiteDatabase paramSupportSQLiteDatabase, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SELECT * FROM sqlite_master WHERE `name` = '");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    Cursor cursor = paramSupportSQLiteDatabase.query(stringBuilder.toString());
    try {
      String str;
      if (cursor.moveToFirst()) {
        str = cursor.getString(cursor.getColumnIndexOrThrow("sql"));
      } else {
        str = "";
      } 
      return parseOptions(str);
    } finally {
      cursor.close();
    } 
  }
  
  public boolean equals(Object<String> paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      String str = this.name;
      if (str != null) {
        if (!str.equals(((FtsTableInfo)paramObject).name))
          return false; 
      } else if (((FtsTableInfo)paramObject).name != null) {
        return false;
      } 
      Set<String> set = this.columns;
      if (set != null) {
        if (!set.equals(((FtsTableInfo)paramObject).columns))
          return false; 
      } else if (((FtsTableInfo)paramObject).columns != null) {
        return false;
      } 
      set = this.options;
      paramObject = (Object<String>)((FtsTableInfo)paramObject).options;
      return (set != null) ? set.equals(paramObject) : ((paramObject == null));
    } 
    return false;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str = this.name;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    Set<String> set = this.columns;
    if (set != null) {
      b2 = set.hashCode();
    } else {
      b2 = 0;
    } 
    set = this.options;
    if (set != null)
      i = set.hashCode(); 
    return (b1 * 31 + b2) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FtsTableInfo{name='");
    stringBuilder.append(this.name);
    stringBuilder.append('\'');
    stringBuilder.append(", columns=");
    stringBuilder.append(this.columns);
    stringBuilder.append(", options=");
    stringBuilder.append(this.options);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\roo\\util\FtsTableInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */