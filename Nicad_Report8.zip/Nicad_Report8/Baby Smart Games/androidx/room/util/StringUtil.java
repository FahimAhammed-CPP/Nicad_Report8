package androidx.room.util;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StringUtil {
  public static final String[] EMPTY_STRING_ARRAY = new String[0];
  
  public static void appendPlaceholders(StringBuilder paramStringBuilder, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      paramStringBuilder.append("?");
      if (i < paramInt - 1)
        paramStringBuilder.append(","); 
    } 
  }
  
  public static String joinIntoString(List<Integer> paramList) {
    if (paramList == null)
      return null; 
    int j = paramList.size();
    if (j == 0)
      return ""; 
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = 0; i < j; i++) {
      stringBuilder.append(Integer.toString(((Integer)paramList.get(i)).intValue()));
      if (i < j - 1)
        stringBuilder.append(","); 
    } 
    return stringBuilder.toString();
  }
  
  public static StringBuilder newStringBuilder() {
    return new StringBuilder();
  }
  
  public static List<Integer> splitToIntList(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<Integer> arrayList = new ArrayList();
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    while (stringTokenizer.hasMoreElements()) {
      String str = stringTokenizer.nextToken();
      try {
        arrayList.add(Integer.valueOf(Integer.parseInt(str)));
      } catch (NumberFormatException numberFormatException) {
        Log.e("ROOM", "Malformed integer list", numberFormatException);
      } 
    } 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\roo\\util\StringUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */