package androidx.room;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

class MultiInstanceInvalidationClient {
  final Context mAppContext;
  
  final IMultiInstanceInvalidationCallback mCallback = new IMultiInstanceInvalidationCallback.Stub() {
      public void onInvalidation(final String[] tables) {
        MultiInstanceInvalidationClient.this.mExecutor.execute(new Runnable() {
              public void run() {
                MultiInstanceInvalidationClient.this.mInvalidationTracker.notifyObserversByTableNames(tables);
              }
            });
      }
    };
  
  int mClientId;
  
  final Executor mExecutor;
  
  final InvalidationTracker mInvalidationTracker;
  
  final String mName;
  
  final InvalidationTracker.Observer mObserver;
  
  final Runnable mRemoveObserverRunnable;
  
  IMultiInstanceInvalidationService mService;
  
  final ServiceConnection mServiceConnection;
  
  final Runnable mSetUpRunnable;
  
  final AtomicBoolean mStopped = new AtomicBoolean(false);
  
  private final Runnable mTearDownRunnable;
  
  MultiInstanceInvalidationClient(Context paramContext, String paramString, InvalidationTracker paramInvalidationTracker, Executor paramExecutor) {
    ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
          MultiInstanceInvalidationClient.this.mService = IMultiInstanceInvalidationService.Stub.asInterface(param1IBinder);
          MultiInstanceInvalidationClient.this.mExecutor.execute(MultiInstanceInvalidationClient.this.mSetUpRunnable);
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {
          MultiInstanceInvalidationClient.this.mExecutor.execute(MultiInstanceInvalidationClient.this.mRemoveObserverRunnable);
          MultiInstanceInvalidationClient.this.mService = null;
        }
      };
    this.mServiceConnection = serviceConnection;
    this.mSetUpRunnable = new Runnable() {
        public void run() {
          try {
            IMultiInstanceInvalidationService iMultiInstanceInvalidationService = MultiInstanceInvalidationClient.this.mService;
            if (iMultiInstanceInvalidationService != null) {
              MultiInstanceInvalidationClient multiInstanceInvalidationClient = MultiInstanceInvalidationClient.this;
              multiInstanceInvalidationClient.mClientId = iMultiInstanceInvalidationService.registerCallback(multiInstanceInvalidationClient.mCallback, MultiInstanceInvalidationClient.this.mName);
              MultiInstanceInvalidationClient.this.mInvalidationTracker.addObserver(MultiInstanceInvalidationClient.this.mObserver);
              return;
            } 
          } catch (RemoteException remoteException) {
            Log.w("ROOM", "Cannot register multi-instance invalidation callback", (Throwable)remoteException);
          } 
        }
      };
    this.mRemoveObserverRunnable = new Runnable() {
        public void run() {
          MultiInstanceInvalidationClient.this.mInvalidationTracker.removeObserver(MultiInstanceInvalidationClient.this.mObserver);
        }
      };
    this.mTearDownRunnable = new Runnable() {
        public void run() {
          MultiInstanceInvalidationClient.this.mInvalidationTracker.removeObserver(MultiInstanceInvalidationClient.this.mObserver);
          try {
            IMultiInstanceInvalidationService iMultiInstanceInvalidationService = MultiInstanceInvalidationClient.this.mService;
            if (iMultiInstanceInvalidationService != null)
              iMultiInstanceInvalidationService.unregisterCallback(MultiInstanceInvalidationClient.this.mCallback, MultiInstanceInvalidationClient.this.mClientId); 
          } catch (RemoteException remoteException) {
            Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", (Throwable)remoteException);
          } 
          MultiInstanceInvalidationClient.this.mAppContext.unbindService(MultiInstanceInvalidationClient.this.mServiceConnection);
        }
      };
    paramContext = paramContext.getApplicationContext();
    this.mAppContext = paramContext;
    this.mName = paramString;
    this.mInvalidationTracker = paramInvalidationTracker;
    this.mExecutor = paramExecutor;
    this.mObserver = new InvalidationTracker.Observer((String[])paramInvalidationTracker.mTableIdLookup.keySet().toArray((Object[])new String[0])) {
        boolean isRemote() {
          return true;
        }
        
        public void onInvalidated(Set<String> param1Set) {
          if (MultiInstanceInvalidationClient.this.mStopped.get())
            return; 
          try {
            IMultiInstanceInvalidationService iMultiInstanceInvalidationService = MultiInstanceInvalidationClient.this.mService;
            if (iMultiInstanceInvalidationService != null) {
              iMultiInstanceInvalidationService.broadcastInvalidation(MultiInstanceInvalidationClient.this.mClientId, param1Set.<String>toArray(new String[0]));
              return;
            } 
          } catch (RemoteException remoteException) {
            Log.w("ROOM", "Cannot broadcast invalidation", (Throwable)remoteException);
          } 
        }
      };
    paramContext.bindService(new Intent(paramContext, MultiInstanceInvalidationService.class), serviceConnection, 1);
  }
  
  void stop() {
    if (this.mStopped.compareAndSet(false, true))
      this.mExecutor.execute(this.mTearDownRunnable); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\room\MultiInstanceInvalidationClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */