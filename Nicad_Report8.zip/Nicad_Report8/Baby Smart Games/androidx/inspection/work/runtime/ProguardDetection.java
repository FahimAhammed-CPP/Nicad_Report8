package androidx.inspection.work.runtime;

import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\002\b\002\030\0002\0020\001B\005¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/inspection/work/runtime/ProguardDetection;", "", "()V", "work-runtime_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
final class ProguardDetection {}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\inspection\work\runtime\ProguardDetection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */