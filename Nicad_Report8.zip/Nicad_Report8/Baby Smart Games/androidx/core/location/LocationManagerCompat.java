package androidx.core.location;

import android.content.Context;
import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.collection.SimpleArrayMap;
import androidx.core.os.CancellationSignal;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.Consumer;
import androidx.core.util.Preconditions;
import java.lang.reflect.Field;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;

public final class LocationManagerCompat {
  private static final long GET_CURRENT_LOCATION_TIMEOUT_MS = 30000L;
  
  private static final long MAX_CURRENT_LOCATION_AGE_MS = 10000L;
  
  private static final long PRE_N_LOOPER_TIMEOUT_S = 5L;
  
  private static Field sContextField;
  
  private static final SimpleArrayMap<Object, Object> sGnssStatusListeners = new SimpleArrayMap();
  
  public static void getCurrentLocation(LocationManager paramLocationManager, String paramString, CancellationSignal paramCancellationSignal, Executor paramExecutor, final Consumer<Location> consumer) {
    if (Build.VERSION.SDK_INT >= 30) {
      Api30Impl.getCurrentLocation(paramLocationManager, paramString, paramCancellationSignal, paramExecutor, consumer);
      return;
    } 
    if (paramCancellationSignal != null)
      paramCancellationSignal.throwIfCanceled(); 
    final Location location = paramLocationManager.getLastKnownLocation(paramString);
    if (location != null && SystemClock.elapsedRealtime() - LocationCompat.getElapsedRealtimeMillis(location) < 10000L) {
      paramExecutor.execute(new Runnable() {
            public void run() {
              consumer.accept(location);
            }
          });
      return;
    } 
    final CancellableLocationListener listener = new CancellableLocationListener(paramLocationManager, paramExecutor, consumer);
    paramLocationManager.requestLocationUpdates(paramString, 0L, 0.0F, cancellableLocationListener, Looper.getMainLooper());
    if (paramCancellationSignal != null)
      paramCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() {
            public void onCancel() {
              listener.cancel();
            }
          }); 
    cancellableLocationListener.startTimeout(30000L);
  }
  
  public static String getGnssHardwareModelName(LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssHardwareModelName(paramLocationManager) : null;
  }
  
  public static int getGnssYearOfHardware(LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssYearOfHardware(paramLocationManager) : 0;
  }
  
  public static boolean isLocationEnabled(LocationManager paramLocationManager) {
    if (Build.VERSION.SDK_INT >= 28)
      return Api28Impl.isLocationEnabled(paramLocationManager); 
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i <= 19)
      try {
        if (sContextField == null) {
          Field field = LocationManager.class.getDeclaredField("mContext");
          sContextField = field;
          field.setAccessible(true);
        } 
        Context context = (Context)sContextField.get(paramLocationManager);
        if (context != null) {
          if (Build.VERSION.SDK_INT == 19) {
            if (Settings.Secure.getInt(context.getContentResolver(), "location_mode", 0) != 0)
              return true; 
          } else {
            boolean bool1 = TextUtils.isEmpty(Settings.Secure.getString(context.getContentResolver(), "location_providers_allowed"));
            return bool1 ^ true;
          } 
          return false;
        } 
      } catch (ClassCastException|SecurityException|NoSuchFieldException|IllegalAccessException classCastException) {} 
    if (paramLocationManager.isProviderEnabled("network") || paramLocationManager.isProviderEnabled("gps"))
      bool = true; 
    return bool;
  }
  
  private static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Handler paramHandler, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore #4
    //   5: iconst_1
    //   6: istore #6
    //   8: iconst_1
    //   9: istore #7
    //   11: iconst_1
    //   12: istore #5
    //   14: iload #4
    //   16: bipush #30
    //   18: if_icmplt -> 90
    //   21: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   24: astore #16
    //   26: aload #16
    //   28: monitorenter
    //   29: aload #16
    //   31: aload_3
    //   32: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   38: astore #15
    //   40: aload #15
    //   42: astore_1
    //   43: aload #15
    //   45: ifnonnull -> 57
    //   48: new androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   51: dup
    //   52: aload_3
    //   53: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   56: astore_1
    //   57: aload_0
    //   58: aload_2
    //   59: aload_1
    //   60: invokevirtual registerGnssStatusCallback : (Ljava/util/concurrent/Executor;Landroid/location/GnssStatus$Callback;)Z
    //   63: ifeq -> 79
    //   66: aload #16
    //   68: aload_3
    //   69: aload_1
    //   70: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   73: pop
    //   74: aload #16
    //   76: monitorexit
    //   77: iconst_1
    //   78: ireturn
    //   79: aload #16
    //   81: monitorexit
    //   82: iconst_0
    //   83: ireturn
    //   84: astore_0
    //   85: aload #16
    //   87: monitorexit
    //   88: aload_0
    //   89: athrow
    //   90: getstatic android/os/Build$VERSION.SDK_INT : I
    //   93: bipush #24
    //   95: if_icmplt -> 199
    //   98: aload_1
    //   99: ifnull -> 108
    //   102: iconst_1
    //   103: istore #8
    //   105: goto -> 111
    //   108: iconst_0
    //   109: istore #8
    //   111: iload #8
    //   113: invokestatic checkArgument : (Z)V
    //   116: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   119: astore #16
    //   121: aload #16
    //   123: monitorenter
    //   124: aload #16
    //   126: aload_3
    //   127: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   130: checkcast androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   133: astore #15
    //   135: aload #15
    //   137: ifnonnull -> 153
    //   140: new androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   143: dup
    //   144: aload_3
    //   145: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   148: astore #15
    //   150: goto -> 158
    //   153: aload #15
    //   155: invokevirtual unregister : ()V
    //   158: aload #15
    //   160: aload_2
    //   161: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   164: aload_0
    //   165: aload #15
    //   167: aload_1
    //   168: invokevirtual registerGnssStatusCallback : (Landroid/location/GnssStatus$Callback;Landroid/os/Handler;)Z
    //   171: ifeq -> 188
    //   174: aload #16
    //   176: aload_3
    //   177: aload #15
    //   179: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   182: pop
    //   183: aload #16
    //   185: monitorexit
    //   186: iconst_1
    //   187: ireturn
    //   188: aload #16
    //   190: monitorexit
    //   191: iconst_0
    //   192: ireturn
    //   193: astore_0
    //   194: aload #16
    //   196: monitorexit
    //   197: aload_0
    //   198: athrow
    //   199: aload_1
    //   200: ifnull -> 209
    //   203: iconst_1
    //   204: istore #8
    //   206: goto -> 212
    //   209: iconst_0
    //   210: istore #8
    //   212: iload #8
    //   214: invokestatic checkArgument : (Z)V
    //   217: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   220: astore #16
    //   222: aload #16
    //   224: monitorenter
    //   225: aload #16
    //   227: aload_3
    //   228: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   231: checkcast androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   234: astore #15
    //   236: aload #15
    //   238: ifnonnull -> 255
    //   241: new androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   244: dup
    //   245: aload_0
    //   246: aload_3
    //   247: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   250: astore #15
    //   252: goto -> 260
    //   255: aload #15
    //   257: invokevirtual unregister : ()V
    //   260: aload #15
    //   262: aload_2
    //   263: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   266: new java/util/concurrent/FutureTask
    //   269: dup
    //   270: new androidx/core/location/LocationManagerCompat$3
    //   273: dup
    //   274: aload_0
    //   275: aload #15
    //   277: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/LocationManagerCompat$GpsStatusTransport;)V
    //   280: invokespecial <init> : (Ljava/util/concurrent/Callable;)V
    //   283: astore_0
    //   284: invokestatic myLooper : ()Landroid/os/Looper;
    //   287: aload_1
    //   288: invokevirtual getLooper : ()Landroid/os/Looper;
    //   291: if_acmpne -> 301
    //   294: aload_0
    //   295: invokevirtual run : ()V
    //   298: goto -> 313
    //   301: aload_1
    //   302: aload_0
    //   303: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   306: istore #8
    //   308: iload #8
    //   310: ifeq -> 594
    //   313: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   316: ldc2_w 5
    //   319: invokevirtual toNanos : (J)J
    //   322: lstore #11
    //   324: invokestatic nanoTime : ()J
    //   327: lstore #13
    //   329: iconst_0
    //   330: istore #4
    //   332: lload #11
    //   334: lstore #9
    //   336: aload_0
    //   337: lload #9
    //   339: getstatic java/util/concurrent/TimeUnit.NANOSECONDS : Ljava/util/concurrent/TimeUnit;
    //   342: invokevirtual get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   345: checkcast java/lang/Boolean
    //   348: invokevirtual booleanValue : ()Z
    //   351: ifeq -> 380
    //   354: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   357: aload_3
    //   358: aload #15
    //   360: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   363: pop
    //   364: iload #4
    //   366: ifeq -> 375
    //   369: invokestatic currentThread : ()Ljava/lang/Thread;
    //   372: invokevirtual interrupt : ()V
    //   375: aload #16
    //   377: monitorexit
    //   378: iconst_1
    //   379: ireturn
    //   380: iload #4
    //   382: ifeq -> 391
    //   385: invokestatic currentThread : ()Ljava/lang/Thread;
    //   388: invokevirtual interrupt : ()V
    //   391: aload #16
    //   393: monitorexit
    //   394: iconst_0
    //   395: ireturn
    //   396: astore_0
    //   397: goto -> 581
    //   400: astore_0
    //   401: iload #4
    //   403: istore #5
    //   405: goto -> 464
    //   408: astore_0
    //   409: iload #4
    //   411: istore #5
    //   413: goto -> 515
    //   416: iload #7
    //   418: istore #4
    //   420: invokestatic nanoTime : ()J
    //   423: lstore #9
    //   425: lload #13
    //   427: lload #11
    //   429: ladd
    //   430: lload #9
    //   432: lsub
    //   433: lstore #9
    //   435: iconst_1
    //   436: istore #4
    //   438: goto -> 336
    //   441: astore_0
    //   442: goto -> 464
    //   445: astore_0
    //   446: iload #6
    //   448: istore #5
    //   450: goto -> 515
    //   453: astore_0
    //   454: iconst_0
    //   455: istore #4
    //   457: goto -> 581
    //   460: astore_0
    //   461: iconst_0
    //   462: istore #5
    //   464: iload #5
    //   466: istore #4
    //   468: new java/lang/StringBuilder
    //   471: dup
    //   472: invokespecial <init> : ()V
    //   475: astore_2
    //   476: iload #5
    //   478: istore #4
    //   480: aload_2
    //   481: aload_1
    //   482: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   485: pop
    //   486: iload #5
    //   488: istore #4
    //   490: aload_2
    //   491: ldc_w ' appears to be blocked, please run registerGnssStatusCallback() directly on a Looper thread or ensure the main Looper is not blocked by this thread'
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: iload #5
    //   500: istore #4
    //   502: new java/lang/IllegalStateException
    //   505: dup
    //   506: aload_2
    //   507: invokevirtual toString : ()Ljava/lang/String;
    //   510: aload_0
    //   511: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   514: athrow
    //   515: iload #5
    //   517: istore #4
    //   519: aload_0
    //   520: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   523: instanceof java/lang/RuntimeException
    //   526: ifne -> 568
    //   529: iload #5
    //   531: istore #4
    //   533: aload_0
    //   534: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   537: instanceof java/lang/Error
    //   540: ifeq -> 555
    //   543: iload #5
    //   545: istore #4
    //   547: aload_0
    //   548: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   551: checkcast java/lang/Error
    //   554: athrow
    //   555: iload #5
    //   557: istore #4
    //   559: new java/lang/IllegalStateException
    //   562: dup
    //   563: aload_0
    //   564: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   567: athrow
    //   568: iload #5
    //   570: istore #4
    //   572: aload_0
    //   573: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   576: checkcast java/lang/RuntimeException
    //   579: athrow
    //   580: astore_0
    //   581: iload #4
    //   583: ifeq -> 592
    //   586: invokestatic currentThread : ()Ljava/lang/Thread;
    //   589: invokevirtual interrupt : ()V
    //   592: aload_0
    //   593: athrow
    //   594: new java/lang/StringBuilder
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: astore_0
    //   602: aload_0
    //   603: aload_1
    //   604: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   607: pop
    //   608: aload_0
    //   609: ldc_w ' is shutting down'
    //   612: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   615: pop
    //   616: new java/lang/IllegalStateException
    //   619: dup
    //   620: aload_0
    //   621: invokevirtual toString : ()Ljava/lang/String;
    //   624: invokespecial <init> : (Ljava/lang/String;)V
    //   627: athrow
    //   628: astore_0
    //   629: aload #16
    //   631: monitorexit
    //   632: goto -> 637
    //   635: aload_0
    //   636: athrow
    //   637: goto -> 635
    //   640: astore_2
    //   641: goto -> 416
    //   644: astore_0
    //   645: iconst_0
    //   646: istore #5
    //   648: goto -> 515
    // Exception table:
    //   from	to	target	type
    //   29	40	84	finally
    //   48	57	84	finally
    //   57	77	84	finally
    //   79	82	84	finally
    //   85	88	84	finally
    //   124	135	193	finally
    //   140	150	193	finally
    //   153	158	193	finally
    //   158	186	193	finally
    //   188	191	193	finally
    //   194	197	193	finally
    //   225	236	628	finally
    //   241	252	628	finally
    //   255	260	628	finally
    //   260	298	628	finally
    //   301	308	628	finally
    //   313	329	644	java/util/concurrent/ExecutionException
    //   313	329	460	java/util/concurrent/TimeoutException
    //   313	329	453	finally
    //   336	364	640	java/lang/InterruptedException
    //   336	364	408	java/util/concurrent/ExecutionException
    //   336	364	400	java/util/concurrent/TimeoutException
    //   336	364	396	finally
    //   369	375	628	finally
    //   375	378	628	finally
    //   385	391	628	finally
    //   391	394	628	finally
    //   420	425	445	java/util/concurrent/ExecutionException
    //   420	425	441	java/util/concurrent/TimeoutException
    //   420	425	580	finally
    //   468	476	580	finally
    //   480	486	580	finally
    //   490	498	580	finally
    //   502	515	580	finally
    //   519	529	580	finally
    //   533	543	580	finally
    //   547	555	580	finally
    //   559	568	580	finally
    //   572	580	580	finally
    //   586	592	628	finally
    //   592	594	628	finally
    //   594	628	628	finally
    //   629	632	628	finally
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback, Handler paramHandler) {
    return (Build.VERSION.SDK_INT >= 30) ? registerGnssStatusCallback(paramLocationManager, ExecutorCompat.create(paramHandler), paramCallback) : registerGnssStatusCallback(paramLocationManager, new InlineHandlerExecutor(paramHandler), paramCallback);
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    if (Build.VERSION.SDK_INT >= 30)
      return registerGnssStatusCallback(paramLocationManager, null, paramExecutor, paramCallback); 
    Looper looper2 = Looper.myLooper();
    Looper looper1 = looper2;
    if (looper2 == null)
      looper1 = Looper.getMainLooper(); 
    return registerGnssStatusCallback(paramLocationManager, new Handler(looper1), paramExecutor, paramCallback);
  }
  
  public static void unregisterGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback) {
    GnssStatusTransport gnssStatusTransport;
    PreRGnssStatusTransport preRGnssStatusTransport;
    if (Build.VERSION.SDK_INT >= 30)
      synchronized (sGnssStatusListeners) {
        gnssStatusTransport = (GnssStatusTransport)null.remove(paramCallback);
        if (gnssStatusTransport != null)
          paramLocationManager.unregisterGnssStatusCallback(gnssStatusTransport); 
        return;
      }  
    if (Build.VERSION.SDK_INT >= 24)
      synchronized (sGnssStatusListeners) {
        preRGnssStatusTransport = (PreRGnssStatusTransport)null.remove(gnssStatusTransport);
        if (preRGnssStatusTransport != null) {
          preRGnssStatusTransport.unregister();
          paramLocationManager.unregisterGnssStatusCallback(preRGnssStatusTransport);
        } 
        return;
      }  
    synchronized (sGnssStatusListeners) {
      GpsStatusTransport gpsStatusTransport = (GpsStatusTransport)null.remove(preRGnssStatusTransport);
      if (gpsStatusTransport != null) {
        gpsStatusTransport.unregister();
        paramLocationManager.removeGpsStatusListener(gpsStatusTransport);
      } 
      return;
    } 
  }
  
  private static class Api28Impl {
    static String getGnssHardwareModelName(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssHardwareModelName();
    }
    
    static int getGnssYearOfHardware(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssYearOfHardware();
    }
    
    static boolean isLocationEnabled(LocationManager param1LocationManager) {
      return param1LocationManager.isLocationEnabled();
    }
  }
  
  private static class Api30Impl {
    static void getCurrentLocation(LocationManager param1LocationManager, String param1String, CancellationSignal param1CancellationSignal, Executor param1Executor, final Consumer<Location> consumer) {
      if (param1CancellationSignal != null) {
        CancellationSignal cancellationSignal = (CancellationSignal)param1CancellationSignal.getCancellationSignalObject();
      } else {
        param1CancellationSignal = null;
      } 
      param1LocationManager.getCurrentLocation(param1String, (CancellationSignal)param1CancellationSignal, param1Executor, new Consumer<Location>() {
            public void accept(Location param2Location) {
              consumer.accept(param2Location);
            }
          });
    }
  }
  
  class null implements Consumer<Location> {
    public void accept(Location param1Location) {
      consumer.accept(param1Location);
    }
  }
  
  private static final class CancellableLocationListener implements LocationListener {
    private Consumer<Location> mConsumer;
    
    private final Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    private final Handler mTimeoutHandler;
    
    Runnable mTimeoutRunnable;
    
    private boolean mTriggered;
    
    CancellableLocationListener(LocationManager param1LocationManager, Executor param1Executor, Consumer<Location> param1Consumer) {
      this.mLocationManager = param1LocationManager;
      this.mExecutor = param1Executor;
      this.mTimeoutHandler = new Handler(Looper.getMainLooper());
      this.mConsumer = param1Consumer;
    }
    
    private void cleanup() {
      this.mConsumer = null;
      this.mLocationManager.removeUpdates(this);
      Runnable runnable = this.mTimeoutRunnable;
      if (runnable != null) {
        this.mTimeoutHandler.removeCallbacks(runnable);
        this.mTimeoutRunnable = null;
      } 
    }
    
    public void cancel() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: invokespecial cleanup : ()V
      //   23: return
      //   24: astore_1
      //   25: aload_0
      //   26: monitorexit
      //   27: aload_1
      //   28: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	24	finally
      //   12	19	24	finally
      //   25	27	24	finally
    }
    
    public void onLocationChanged(Location param1Location) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: getfield mConsumer : Landroidx/core/util/Consumer;
      //   23: astore_2
      //   24: aload_0
      //   25: getfield mExecutor : Ljava/util/concurrent/Executor;
      //   28: new androidx/core/location/LocationManagerCompat$CancellableLocationListener$2
      //   31: dup
      //   32: aload_0
      //   33: aload_2
      //   34: aload_1
      //   35: invokespecial <init> : (Landroidx/core/location/LocationManagerCompat$CancellableLocationListener;Landroidx/core/util/Consumer;Landroid/location/Location;)V
      //   38: invokeinterface execute : (Ljava/lang/Runnable;)V
      //   43: aload_0
      //   44: invokespecial cleanup : ()V
      //   47: return
      //   48: astore_1
      //   49: aload_0
      //   50: monitorexit
      //   51: aload_1
      //   52: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	48	finally
      //   12	19	48	finally
      //   49	51	48	finally
    }
    
    public void onProviderDisabled(String param1String) {
      onLocationChanged((Location)null);
    }
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
    
    public void startTimeout(long param1Long) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: new androidx/core/location/LocationManagerCompat$CancellableLocationListener$1
      //   15: dup
      //   16: aload_0
      //   17: invokespecial <init> : (Landroidx/core/location/LocationManagerCompat$CancellableLocationListener;)V
      //   20: astore_3
      //   21: aload_0
      //   22: aload_3
      //   23: putfield mTimeoutRunnable : Ljava/lang/Runnable;
      //   26: aload_0
      //   27: getfield mTimeoutHandler : Landroid/os/Handler;
      //   30: aload_3
      //   31: lload_1
      //   32: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
      //   35: pop
      //   36: aload_0
      //   37: monitorexit
      //   38: return
      //   39: astore_3
      //   40: aload_0
      //   41: monitorexit
      //   42: aload_3
      //   43: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	39	finally
      //   12	38	39	finally
      //   40	42	39	finally
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$0.mTimeoutRunnable = null;
      this.this$0.onLocationChanged((Location)null);
    }
  }
  
  class null implements Runnable {
    public void run() {
      consumer.accept(location);
    }
  }
  
  private static class GnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    GnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(int param1Int) {
      this.mCallback.onFirstFix(param1Int);
    }
    
    public void onSatelliteStatusChanged(GnssStatus param1GnssStatus) {
      this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(param1GnssStatus));
    }
    
    public void onStarted() {
      this.mCallback.onStarted();
    }
    
    public void onStopped() {
      this.mCallback.onStopped();
    }
  }
  
  private static class GpsStatusTransport implements GpsStatus.Listener {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    GpsStatusTransport(LocationManager param1LocationManager, GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mLocationManager = param1LocationManager;
      this.mCallback = param1Callback;
    }
    
    public void onGpsStatusChanged(int param1Int) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4)
              return; 
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onSatelliteStatusChanged(gnssStatus);
                    }
                  });
              return;
            } 
          } else {
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onFirstFix(ttff);
                    }
                  });
              return;
            } 
          } 
        } else {
          executor.execute(new Runnable() {
                public void run() {
                  if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                    return; 
                  LocationManagerCompat.GpsStatusTransport.this.mCallback.onStopped();
                }
              });
          return;
        } 
      } else {
        executor.execute(new Runnable() {
              public void run() {
                if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                  return; 
                LocationManagerCompat.GpsStatusTransport.this.mCallback.onStarted();
              }
            });
      } 
    }
    
    public void register(Executor param1Executor) {
      boolean bool;
      if (this.mExecutor == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttff);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(gnssStatus);
    }
  }
  
  private static final class InlineHandlerExecutor implements Executor {
    private final Handler mHandler;
    
    InlineHandlerExecutor(Handler param1Handler) {
      this.mHandler = (Handler)Preconditions.checkNotNull(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (Looper.myLooper() == this.mHandler.getLooper()) {
        param1Runnable.run();
        return;
      } 
      if (this.mHandler.post((Runnable)Preconditions.checkNotNull(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mHandler);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
  
  private static class PreRGnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    PreRGnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(final int ttffMillis) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onFirstFix(ttffMillis);
            }
          });
    }
    
    public void onSatelliteStatusChanged(final GnssStatus status) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
            }
          });
    }
    
    public void onStarted() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStarted();
            }
          });
    }
    
    public void onStopped() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStopped();
            }
          });
    }
    
    public void register(Executor param1Executor) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Executor != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Preconditions.checkArgument(bool1, "invalid null executor");
      if (this.mExecutor == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Preconditions.checkState(bool1);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttffMillis);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\location\LocationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */