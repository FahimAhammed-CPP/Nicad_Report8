package androidx.core.view;

public interface WindowInsetsAnimationControlListenerCompat {
  void onCancelled(WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat);
  
  void onFinished(WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat);
  
  void onReady(WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\view\WindowInsetsAnimationControlListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */