package androidx.core.telephony;

import android.os.Build;
import android.telephony.SubscriptionManager;
import java.lang.reflect.Method;

public class SubscriptionManagerCompat {
  private static Method sGetSlotIndexMethod;
  
  public static int getSlotIndex(int paramInt) {
    if (paramInt == -1)
      return -1; 
    if (Build.VERSION.SDK_INT >= 29)
      return Api29Impl.getSlotIndex(paramInt); 
    try {
      if (sGetSlotIndexMethod == null) {
        if (Build.VERSION.SDK_INT >= 26) {
          sGetSlotIndexMethod = SubscriptionManager.class.getDeclaredMethod("getSlotIndex", new Class[] { int.class });
        } else {
          sGetSlotIndexMethod = SubscriptionManager.class.getDeclaredMethod("getSlotId", new Class[] { int.class });
        } 
        sGetSlotIndexMethod.setAccessible(true);
      } 
      Integer integer = (Integer)sGetSlotIndexMethod.invoke(null, new Object[] { Integer.valueOf(paramInt) });
      return (integer != null) ? integer.intValue() : -1;
    } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
      return -1;
    } 
  }
  
  private static class Api29Impl {
    static int getSlotIndex(int param1Int) {
      return SubscriptionManager.getSlotIndex(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\telephony\SubscriptionManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */