package androidx.lifecycle;

public interface LifecycleEventObserver extends LifecycleObserver {
  void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\lifecycle\LifecycleEventObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */